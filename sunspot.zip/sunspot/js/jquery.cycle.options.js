$(document).ready(function() {

$('#slider').cycle({ 
    pause: 1, 
    next:   '#next', 
    prev:   '#prev'
});
});